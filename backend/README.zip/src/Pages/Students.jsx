import {
  faSave,
  faTimesCircle,
  faUserEdit,
  faUserPlus,
} from "@fortawesome/free-solid-svg-icons"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import React, { useEffect, useState } from "react"
import Modal from "../Components/Modal"
import GraphQLFetch from "../Helpers/GraphQLFetch"

function Students() {
  const [{ errors, data }, setStudents] = useState([])
  const [schools, setSchools] = useState([])
  const [addStudent, setAddStudent] = useState(false)
  const [name, setName] = useState("")
  const [regno, setRegno] = useState("")
  const [school, setSchool] = useState("")

  useEffect(() => {
    fetchStudents()
    fetchSchools()
  }, [])

  async function fetchStudents() {
    let res = await GraphQLFetch(`{
      students{
        reg_no
        name
        school{
          name
          code
        }
      }
    }`)
    setStudents(res)
  }

  async function fetchSchools() {
    let res = await GraphQLFetch(`{
      schools{
        code
        name
      }
    }`)
    setSchools(res.data.schools)
  }

  return (
    <div className="students">
      <div className="title">Students</div>
      {errors && errors.map((e) => <div>Error</div>)}
      {data && (
        <div className="list">
          <div className="options">
            <div className="button" onClick={(e) => setAddStudent(true)}>
              <FontAwesomeIcon icon={faUserPlus} />
              Add
            </div>
          </div>
          <table>
            <tr>
              <th>Registration Number</th>
              <th>Name</th>
              <th>School</th>
              <th></th>
            </tr>
            {data.students.map(({ name, reg_no, school }) => (
              <tr>
                <td>{reg_no}</td>
                <td>{name}</td>
                <td>
                  {school.name} ({school.code.toUpperCase()})
                </td>
                <td style={{ display: "flex", flexDirection: "row" }}>
                  <div className="button small">
                    <FontAwesomeIcon icon={faUserEdit} />
                    Edit
                  </div>
                  <div
                    className="button small"
                    onClick={(e) => {
                      window.confirm("Are you sure?")
                    }}
                  >
                    <FontAwesomeIcon icon={faTimesCircle} />
                    Delete
                  </div>
                </td>
              </tr>
            ))}
          </table>
        </div>
      )}
      <Modal
        title="Add Student"
        shown={addStudent}
        hideMe={() => setAddStudent(false)}
      >
        <div className="input">
          <label htmlFor="">Registration Number</label>
          <input
            onChange={(e) => setRegno(e.target.value)}
            style={{ width: 300 }}
            type="text"
          />
        </div>
        <div className="input">
          <label htmlFor="">Name</label>
          <input
            onChange={(e) => setName(e.target.value)}
            style={{ width: 300 }}
            type="text"
          />
        </div>
        <div className="input">
          <label htmlFor="">School</label>
          <select onChange={(e) => setSchool(e.target.value)} name="" id="">
            {schools.map((s) => (
              <option style={{ textTransform: "capitalize" }} value={s.code}>
                {s.name}
              </option>
            ))}
          </select>
        </div>
        <div className="options">
          <div
            className="button black"
            onClick={async () => {
              let { errors, data } = await GraphQLFetch(`mutation{
                addStudent(reg_no: "${regno}", name: "${name}", school: "${school}"){
                  name
                  reg_no
                  school{
                    name
                    code
                  }
                }
              }`)
              fetchStudents()
              if (errors) {
                alert(
                  "Failed to add student\n\n" + errors.map((e) => e.message)
                )
              } else {
                alert(`Student Added`)
                setAddStudent(false)
              }
            }}
          >
            <FontAwesomeIcon icon={faSave} />
            &nbsp; Save
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default Students
