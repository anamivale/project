import {
  faSave,
  faSchool,
  faTimesCircle,
  faUserEdit,
  faUserPlus,
} from "@fortawesome/free-solid-svg-icons"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import React, { useEffect, useState } from "react"
import Modal from "../Components/Modal"
import GraphQLFetch from "../Helpers/GraphQLFetch"
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js"

import { Doughnut } from "react-chartjs-2"
ChartJS.register(ArcElement, Tooltip, Legend)

function Candidates() {
  const [schools, setSchools] = useState([])
  const [addStudent, setAddStudent] = useState(false)
  const [regno, setRegno] = useState("")
  const [candidates, setCandidates] = useState([])

  useEffect(() => {
    fetchCandidates()
  }, [])

  async function fetchCandidates() {
    let sch = await fetchSchools()

    for (let s of sch) {
      let candidates = await GraphQLFetch(`{
        schoolCandidates(school: "${s.code}"){
          name
          reg_no
          voteCount
        }
      }`)
      // console.log(candidates.data.schoolCandidates)
      s.candidates = candidates.data.schoolCandidates
    }
    setSchools(sch)
  }

  async function fetchSchools() {
    let res = await GraphQLFetch(`{
      schools{
        name
        code
      }
    }`)
    return res.data.schools
  }

  return (
    <div className="students">
      <div className="title">Candidates</div>
      {schools.map((s) => (
        <div className="can-school">
          <div className="school-name">
            <FontAwesomeIcon
              icon={faSchool}
              style={{ marginRight: 5, transform: "translateY(-1px)" }}
            />
            {s.name}
          </div>
          {s.candidates.length > 0 ? (
            <div className="can-details">
              <div className="can-chart">
                <Doughnut
                  data={{
                    labels: s.candidates.map((c) => c.name),
                    datasets: [
                      {
                        label: "# of Votes",
                        data: s.candidates.map((c) => parseInt(c.voteCount)),
                        backgroundColor: [
                          "rgba(255, 99, 132, 0.2)",
                          "rgba(54, 162, 235, 0.2)",
                          "rgba(255, 206, 86, 0.2)",
                          "rgba(75, 192, 192, 0.2)",
                          "rgba(153, 102, 255, 0.2)",
                          "rgba(255, 159, 64, 0.2)",
                        ],
                        borderColor: [
                          "rgba(255, 99, 132, 1)",
                          "rgba(54, 162, 235, 1)",
                          "rgba(255, 206, 86, 1)",
                          "rgba(75, 192, 192, 1)",
                          "rgba(153, 102, 255, 1)",
                          "rgba(255, 159, 64, 1)",
                        ],
                        borderWidth: 1,
                      },
                    ],
                  }}
                />
              </div>
              <ul className="can-list">
                {s.candidates.map((c) => (
                  <li className="candidate">
                    {c.name}{" "}
                    <b>
                      <i>({c.voteCount.toLocaleString()} Votes)</i>
                    </b>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div className="message">No Candidate Found!</div>
          )}
          <button onClick={() => setAddStudent(true)}>Add Candidate</button>
        </div>
      ))}

      <Modal
        title="Add Candidate"
        shown={addStudent}
        hideMe={() => setAddStudent(false)}
      >
        <div className="input">
          <label htmlFor="">Registration Number</label>
          <input
            onChange={(e) => setRegno(e.target.value)}
            style={{ width: 300 }}
            type="text"
          />
        </div>

        <div className="options">
          <div
            className="button black"
            onClick={async () => {
              let { errors, data } = await GraphQLFetch(`mutation{
                addCandidate(reg_no: "${regno}"){
                  reg_no
                  name
                  school{
                    name
                    code
                  }
                }
              }`)
              if (errors) {
                alert(
                  "Failed to add Candidate\n\n" + errors.map((e) => e.message)
                )
              } else {
                alert(`Candidate Added`)
                setAddStudent(false)
              }
              fetchCandidates()
            }}
          >
            <FontAwesomeIcon icon={faSave} />
            &nbsp; Save
          </div>
        </div>
      </Modal>
    </div>
  )
}

export default Candidates
